package org.example.U3.controller;

public class Main {
    public static void main(String[] args) {


        Controller theController = new Controller();
    }
}
