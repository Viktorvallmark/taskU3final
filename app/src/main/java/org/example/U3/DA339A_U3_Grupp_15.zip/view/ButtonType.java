package org.example.U3.view;

public enum ButtonType {
    Add,
    PerUnitItem,
    Cake,
    MakeCake,
    NoChoice,
    Order,
    OrderHistory,
    ViewOrder,
}
