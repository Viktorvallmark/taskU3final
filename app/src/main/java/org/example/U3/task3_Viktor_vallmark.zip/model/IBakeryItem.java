package org.example.U3.model;

public interface IBakeryItem {

  String getName();
  void setName(String name);
  double getPrice();

}
