package org.example.U3.controller;

public class Main {
    public static void main(String[] args) {


        //TODO: Make an Order class in model to handle the order string and the order cost.
        //TODO: Current implementation is a hack job.
        //TODO: Refactor in the use of Order class.


        Controller theController = new Controller();
    }
}
