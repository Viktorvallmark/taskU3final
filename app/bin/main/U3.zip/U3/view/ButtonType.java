package view;

public enum ButtonType {
    Add,
    PerUnitItem,
    Cake,
    MakeCake,
    NoChoice,
    Order,
    OrderHistory,
    ViewOrder,
}
